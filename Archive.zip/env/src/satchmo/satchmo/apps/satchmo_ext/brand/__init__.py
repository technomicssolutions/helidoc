from satchmo_store.shop.satchmo_settings import add_setting_defaults

brand_settings_defaults = {
    'BRAND_SLUG' : 'brand',
    }

add_setting_defaults(brand_settings_defaults)