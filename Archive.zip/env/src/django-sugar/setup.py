from setuptools import setup, find_packages
setup(
    name='Django Sugar',
    version='1.5',
    author='Skirmantas Jurgaitis',
    author_email='skirmantas@ivc.lt',
    packages=find_packages(),
)
