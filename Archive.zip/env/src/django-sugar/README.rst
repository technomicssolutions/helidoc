Django Temltatetags
===================

cms_utils_tags
--------------

Load tags:

    {% load cms_utils_tags %}

get_first_placeholder_plugin
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Examle:

    {% get_first_placeholder_plugin cms_page 'Photologue Photo' as photo  %}


form_utils
----------

Load tags:

    {% load form_utils %}
