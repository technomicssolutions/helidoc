""" Methods to work on temporary files. """
import tempfile
import pickle
import os

from django.core.files.uploadedfile import TemporaryUploadedFile, UploadedFile
from django.conf import settings

def tempfile_id(file_name, prefix='', suffix=''):
    """ Returns a unique part of temporary file name. """
    return os.path.basename(file_name)[len(prefix):-len(suffix) or None]

def tempfile_name(file_id, prefix='', suffix=''):
    """ Returns absolute path to temporary file. """
    file_dir = tempfile.gettempdir()
    return os.path.join(file_dir, ''.join([prefix, str(file_id), suffix]))

def save_object(obj, prefix='', suffix=''):
    """ Pickle and save an object to a file in temporary files folder.

        Return:
            String - a unique id which can be used to for restor_object method.
    """
    suffix = suffix + '.pickle'
    file = tempfile.NamedTemporaryFile(prefix=prefix, suffix=suffix,
                                       delete=False)
    pickle.dump(obj, file)
    file.close()
    return tempfile_id(file.name)

def load_object(object_id, prefix='', suffix=''):
    """ Restore an object saved with save_object() method.  Raise IOError if 
    object cannot be restored.  """
    suffix = suffix + '.pickle'
    file = open(tempfile_name(object_id), 'rb')
    return pickle.load(file)

def save_uploadedfile(uploaded_file, prefix='', suffix=''):
    """ Save an UploadedFile object to file so that it will be possible to load
    it later.

    Usage example:

        # Save file:
        file_id = save_uploadedfile(uploaded_file)

        # Restore it:
        uploaded_file = load_uploadefile(file_id)

    We need this method because python can't pickle uploaded_file object,
    thus we can't do: save_object(uploaded_file).
    """
    suffix = suffix + '.file_data'
    if not hasattr(uploaded_file, 'temporary_file_path'):
       # file is an in memory file. We need to save it to disk first.
       temp_dir = settings.FILE_UPLOAD_TEMP_DIR or tempfile.gettempdir()
       file_ = tempfile.NamedTemporaryFile(suffix='.upload', dir=temp_dir,
                                           delete=False)
       for chunk in uploaded_file.chunks():
           file_.write(chunk)
       file_.close()
       temporary_file_path = file_.name
       uploaded_file.close()
    else:
       temporary_file_path = uploaded_file.temporary_file_path()

    # data required to build an TemporaryUploadedFile instance:
    file_data = {
        'name': uploaded_file.name,
        'size': uploaded_file.size,
        'content_type': uploaded_file.content_type,
        'charset': uploaded_file.charset,
        'temporary_file_path': temporary_file_path,
    }
    return save_object(file_data, prefix, suffix)

def load_uploadedfile(file_id, prefix='', suffix=''):
    """ Load a file saved with save_uploadedfile. If file is lost: IOError is
    raised. """
    suffix = suffix + '.file_data'
    try:
        file_data = load_object(file_id, prefix, suffix)
    except IOError:
        raise IOError("Temporary file %s cannot be restored because file's "
                      "metadata has been lost." % file_id)

    class RestoredTemporaryFile(TemporaryUploadedFile):
        """ Little magic happens here. We want to restore TemporaryUploadedFile.
        We need to override its init method because it creates a new empty file
        when it is initialized. """
        def __init__(self, data):
            """ Will open existing temporary file instead of creating new empty
            file. """
            kwargs = {
                'file': open(data['temporary_file_path'], 'rb'),
                'name': data['name'],
                'size': data['size'],
                'content_type': data['content_type'],
                'charset': data['charset']
            }
            # bypass the TemporaryUploadedFile.__init__:
            UploadedFile.__init__(self, **kwargs)

    try:
        uploaded_file = RestoredTemporaryFile(file_data)
    except IOError:
        raise IOError("Temporary file %s cannot be restored because file's "
                      "content at %s has been lost."
                          % (file_id, file_data['temporary_file_path']))
    return uploaded_file
