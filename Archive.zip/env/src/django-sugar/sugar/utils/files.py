import itertools
import os
import re

from django.conf import settings

def unique_file_name(file):
    """ Append a counter to the end of file name if 
    such file allready exist."""
    if not os.path.isfile(file):
        # do nothing if such file doesn exists
        return file 
    # test if file has extension:
    if re.match('.+\.[a-zA-Z0-9]+$', os.path.basename(file)):
        # yes: append counter before file extension.
        name_func = \
            lambda f, i: re.sub('(\.[a-zA-Z0-9]+)$', '_%i\\1' % i, f)
    else:
        # filename has no extension, append counter to the file end
        name_func = \
            lambda f, i: ''.join([f, '_%i' % i])
    for new_file_name in \
            (name_func(file, i) for i in itertools.count(1)):
        if not os.path.exists(new_file_name):
            return new_file_name

def save_uploaded_file(uploaded_file, dir=''):
    """ Save an uploaded file to a location accesable from web. Return absolute
    url to saved file. """
    if dir:
        dir = os.path.join(settings.MEDIA_ROOT, dir)
    filepath = os.path.join(dir, uploaded_file.name)
    filepath = unique_file_name(filepath)
    saved_uploaded_file = open(filepath, 'wb')
    for chunk in uploaded_file.chunks():
        saved_uploaded_file.write(chunk)
    saved_uploaded_file.close()
    # TODO: ABSOLUTE_MEDIA_URL documentation
    # return absolute url to file:
    return filepath.replace(settings.MEDIA_ROOT.rstrip('/\\'),
                            settings.ABSOLUTE_MEDIA_URL.rstrip('/'))
