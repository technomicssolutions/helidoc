
def save_uploaded_file(file, dir=''):
    ''' Save uploaded file to a place accessable from web '''
