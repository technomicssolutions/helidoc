from django.utils.importlib import import_module

def get_class(class_path):
    ''' Get class by full path to that class.

        Example:
        >>> try:
        >>>     someclass = get_class('somepackage.somemodule.someclass')
        >>> except ImportError:
        >>>     pass
        >>> assert get_class('datetime.date')
    '''
    try:
        dot = class_path.rindex('.')
    except ValueError:
        raise ImportError('%s isn\'t a valid path to class' % class_path)
    module, classname = class_path[:dot], class_path[dot+1:]
    mod = import_module(module)
    try:
        cls = getattr(mod, classname)
    except AttributeError:
        raise ImportError('Module "%s" does not define a "%s" class' \
                            % (module, classname))
    return cls
