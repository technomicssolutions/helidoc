from django import forms
from django.utils.simplejson import dumps
from sugar.utils import temporary

class MultiFileInput(forms.widgets.FileInput):
    """A multiple-file file input widget. 
       This widget keeps uploaded files """

    class Media:
        js = ('js/jquery.js', 'js/jquery.multifile.js', )

    def render(self, name, value, attrs=None):
        """ If value is not set render as usual, but with added class.
            If value is present, render uploaded files list. """
        if attrs is None:
            attrs = {}

        if attrs.has_key('class'):
            attrs['class'] += ' multi'
        else:
            attrs['class'] = 'multi'
        if 'maxlength' not in attrs:
            attrs['maxlength'] = 10

        if value:
            # add uploaded files into html.
            # TODO: this is very hacky. javascript is event more hacky and you
            # can find it at tilde/media/tilde/base.js
            attrs['uploaded-files']  \
                = dumps(self.get_files_dict(value)).replace('"', '&quot;')

        return super(MultiFileInput, self).render(name, None, attrs=attrs)

    def get_files_dict(self, value):
        """ Take a list of files from value_from_datadict() 
            Return a dictioanry:
                { <Temporary file id> : <uploaded file name> }

            Used to output uploaded files to user.
        """
        files = {}
        for file_obj in value:
            if not file_obj:
                continue
            files[ file_obj.tmp_object_id ] = file_obj.name
        return files

    def value_from_datadict(self, data, files, name):
        """ Return a list of the uploaded files """
        allfiles = []
        if name in data:
            """ load files from previous upload """
            savedfiles = data.getlist(name)
            for file_id in savedfiles:
                if not file_id:
                    continue
                try:
                    uploaded_file = temporary.load_uploadedfile(file_id)
                    uploaded_file.tmp_object_id = file_id
                    # check if file is readable:
                    open(uploaded_file.temporary_file_path()).close()
                except IOError:
                    # Append an empty value to list.
                    # MultiFileField will detect it and will be able to
                    # raise ValidationError. User will be reported
                    # that we have failed to upload a file.
                    allfiles.append(None)
                    continue
                allfiles.append(uploaded_file)
        if files:
            for uploaded_file in files.getlist(name):
                """ Store files to temporary location, so that they could
                be reused if form fails with validation errors. """
                file_id = temporary.save_uploadedfile(uploaded_file)
                uploaded_file.tmp_object_id = file_id

                # add file to our file-list:
                allfiles.append(uploaded_file)
        return allfiles
