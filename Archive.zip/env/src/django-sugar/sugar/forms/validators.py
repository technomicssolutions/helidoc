# encoding: utf-8

from django.utils.translation import ugettext as _
from django.core.validators import RegexValidator

validate_phonenumber = \
    RegexValidator(r'^\+?[0-9]{7,15}$', _('Enter correct phone number.'),
                   'invalid_phonenumber')
