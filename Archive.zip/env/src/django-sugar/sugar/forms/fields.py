from django.core import validators
from django.core.exceptions import ValidationError
from django.forms import Field, CharField
from django.utils.translation import ugettext_lazy as _

from widgets import MultiFileInput
from validators import validate_phonenumber

class MultiFileField(Field):
    """A multiple-valued file input field."""

    widget = MultiFileInput()
    default_error_messages = {
        'invalid': _(u"No file was submitted! Check the \
                       encoding type on the form."),
        'missing': _(u"No file was submitted."),
        'empty': _(u"The submitted file is empty."),
        'max_length': _(u'Ensure this filename has at most %(max)d \
                          characters (it has %(length)d).'),
        'upload_error': _(u'File uploading failed. Please try again.'),
    }

    # TODO: make max length work as a limit for file number
    # TODO: add limits for file size and limit for all uploaded files size sum
    def __init__(self, *args, **kwargs):
        self.max_length = kwargs.pop('max_length', None)
        if self.max_length:
            self.widget = MultiFileInput(attrs={'maxlength': self.max_length})
        super(MultiFileField, self).__init__(*args, **kwargs)

    def to_python(self, data):
        """Validate and Pythonise the value from the Widget."""
        if data in validators.EMPTY_VALUES:
            return None

        for datum in data:
            if datum == None:
                raise ValidationError(self.error_messages['upload_error'])
            # UploadedFile objects should have name and size attributes.
            try:
                file_name = datum.name
                file_size = datum.size
            except AttributeError:
                raise ValidationError(self.error_messages['invalid'])

            if not file_name:
                raise ValidationError(self.error_messages['invalid'])
            if not file_size:
                raise ValidationError(self.error_messages['empty'])

        return data

    def clean(self, data, initial=None):
        if not data and initial:
            return initial
        return super(MultiFileField, self).clean(data)

class PhonenumberField(CharField):
    default_validators = [validate_phonenumber]
