from django import template
from django.forms.forms import pretty_name
from django.utils.safestring import mark_safe


register = template.Library()


@register.filter(name='formtype')
def form_type(form):
    """ Return string for form enctype attribute """
    if form.is_multipart:
        return 'multipart/form-data'
    else:
        return 'text/plain'


@register.filter(name='fieldval')
def field_value(boundfield):
    """ Returns direct value from data passed to form.
    widget.value_from_datadict() is used to get value.
    """
    widget = boundfield.field.widget
    data = boundfield.form.data
    files = boundfield.form.files
    name = boundfield.html_name
    return widget.value_from_datadict(data, files, name)


@register.filter(name='fieldclean')
def field_cleaned(boundfield):
    """ Get cleaned value of bound field. Empty value is returned if form is
    not valid. """
    if not boundfield.form.is_valid():
        return u''
    return boundfield.form.cleaned_data.get(boundfield.name, '')


@register.filter(name='choiceval')
def choice_literal(boundfield):
    """ Get literal value from field's choices. Empty value is returned if form
    is not valid"""
    if not boundfield.form.is_valid():
        return u''
    value = boundfield.form.cleaned_data.get(boundfield.name, '')
    return dict(boundfield.field.choices).get(int(value), '')


@register.filter(name='fielderrorclass')
def field_error_class(boundfield):
    """ Get a string which can be used in `class` attribute on html element.

    Classes returned by this function:

        error - if any kind of error is present

        empty_value - if empty value error is present

        ... and other default django errors.
    """
    errors = []
    if boundfield.errors and boundfield.field.error_messages:
        errors.append('error')
        # is there an easier way to get an error name instead of string?
        for error_key, error_val in boundfield.field.error_messages.items():
            if error_val in boundfield.errors:
                errors.append(error_key)
        return mark_safe( ' '.join(errors) )
    return ''


@register.filter(name='fieldhelptext')
def helptext_html(boundfield):
    """ IVC standart to render a helptext for field. """
    if not boundfield.help_text:
        return u''
    wrapper = u'<span class="helptext">%s</span>'
    return mark_safe( wrapper % boundfield.help_text )


@register.filter(name='fieldlabelhtml')
def label_html(boundfield):
    """ IVC standart to render field's label. An asterisk (*), wrapped with
    a <span>, is added to label if field is required. A colon (:) is added to
    every label."""
    label = boundfield.field.label or pretty_name(boundfield.name)
    if label.endswith('?') or label.endswith(':'):
        colon = ''
    else:
        colon = ':'
    wrapper = \
        u'<label for="%(field_id)s">%(label)s%(colon)s%(required)s</label>'
    required_html = \
        '<span class="required">*</span>' if boundfield.field.required else ''
    return mark_safe( wrapper % {
        'field_id': ''.join(['id_', boundfield.html_name]),
        'label': label,
        'required': required_html,
        'colon': colon
    } )


@register.filter(name='fieldrender')
def field_render(boundfield):
    """ IVC standart to render a field: label, input widget, helptext, errors
    all are wrapped with a <li> element.
        If field is hidden: return output for field's widget only.
        If field is required a `required` class is added on <li> tag."""
    if boundfield.is_hidden:
        return unicode(boundfield)
    wrapper = \
        '<li class="%(widget_class)s %(html_name)s %(error_class)s">' \
        '%(label_html)s%(field_html)s%(helptext_html)s%(error_html)s</li>'
    return mark_safe( wrapper % {
        'html_name': boundfield.html_name,
        'error_class': field_error_class(boundfield),
        'label_html': label_html(boundfield),
        'field_html': boundfield,
        'helptext_html': helptext_html(boundfield),
        'error_html': boundfield.errors,
        'widget_class': boundfield.field.widget.__class__.__name__,
    } )


@register.filter(name='formrender')
def form_render(form):
    """ IVC standart to render all form fields. Hidden fields are rendered
    first. Then other fields fallow. Output is a set of <li> elements wrapped
    into an <ul class="form FormClassName">. You will need to wrap with a <form>
    tag manually. """
    output = []
    for field in form.hidden_fields():
        output.append(unicode(field))
    #output.append('<ul class="form %s">' % form.__class__.__name__)
    for field in form.visible_fields():
        output.append(field_render(field))
    return mark_safe(''.join(output))


@register.filter(name='classname')
def class_name(object):
    return object.__class__.__name__


def with_field(boundfield):
    """ Makes writing a custom html for field easy and comfortable.

    This templatetag will add fallowing context into wrapped code:

        value
            value returned by field_value()

        cleaned
            value returned by field_cleaned()

        choice_value
            value returned by choice_value

        error_class
            value returned by field_error_classes()

        errors
            list of errors. Renders an ul>li list by default

        label
            label as simple literal string

        label_tag
            django standart to render label

        label_html
            IVC standart to render label

        name
            name of field as defined in Form class.

        html_name
            name which should be used for input. Form prefix is taken into
            account

        help_text
            Help text associated with the field

        is_hidden
            if field is hidden.
    """
    # not yet implemented
    pass


class WithFieldNode(template.Node):
    pass
