from django import template


class FirstPlaceholderPluginNode(template.Node):
    def __init__(self, item, plugin_name, varname):
        self.item = item
        self.plugin_name = self.clean_plugin_name(plugin_name)
        self.varname = varname

    def clean_plugin_name(self, value):
        """Plugin name writed to this tag could be with surrounding
        quotes, so replace them to nothing.
        """
        value = value.replace("'", '')
        value = value.replace('"', '')
        return value

    def render(self, context):
        self.placeholders = context[self.item].placeholders
        for placeholder in self.placeholders.all():
            for cmsplugin in placeholder.cmsplugin_set.all():
                plugin_class = cmsplugin.get_plugin_class()
                if self.plugin_name == plugin_class.__name__:
                    context[self.varname] = cmsplugin
        return ''

def get_first_placeholder_plugin(parser, token):
    """
        {% get_first_placeholder_plugin cms_page 'Photologue Photo' as photo  %}
    """
    params = token.split_contents()
    return FirstPlaceholderPluginNode(params[1], params[2], params[4])


register = template.Library()
register.tag(get_first_placeholder_plugin)
