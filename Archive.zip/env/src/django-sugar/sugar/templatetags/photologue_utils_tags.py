from django import template


def image_thumbnail_url(image, thumbnail_name):
    """
        {{ photo|image_thumbnail_url:"small" }}
    """
    thumbnail_name_function = 'get_' + thumbnail_name + '_url'
    thumbnail_func = getattr(image, thumbnail_name_function)
    return thumbnail_func()


register = template.Library()
register.filter(image_thumbnail_url)
